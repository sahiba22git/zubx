<!-- Header -->
<?php $this->load->view('header');?>
<!-- / Header -->

<!-- Footer -->
<?php $this->load->view('footer');?>
<!-- / Footer -->