</div>
    <!-- login wrapper end -->
    
    <!-- javascript -->
    <script src="<?php echo base_url('assets/frontend/js/jquery-3.6.0.min.js');?>"></script>
    <!-- bootstrap 5 -->
    <script src="<?php echo base_url('assets/frontend/js/bootstrap.bundle.min.js');?>"></script>
    <!-- main -->
    <script src="<?php echo base_url('assets/frontend/js/main.js');?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.3/jquery.validate.min.js"></script>
</body>
</html>