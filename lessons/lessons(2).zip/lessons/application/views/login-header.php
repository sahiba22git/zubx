<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>English Lessons | Login</title>
    <!-- favicon -->
    <link rel="shortcut icon" href="<?php echo base_url('assets/frontend/img/logo.png');?>" type="image/x-icon">
    <!-- bootstrap 5 -->
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/bootstrap.min.css');?>">
    <!-- style -->
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/style.css');?>">
    <!-- responsive -->
    <link rel="stylesheet" href="<?php echo base_url('assets/frontend/css/responsive.css');?>">
</head>
<body>