

    <!-- jQuery -->

    <script src="bower_components/jquery/dist/jquery.min.js"></script>

    <script src="bower_components/bootstrap/dist/js/bootstrap.min.js"></script>

    <script src="bower_components/metisMenu/dist/metisMenu.min.js"></script>

    <script src="bower_components/datatables/media/js/jquery.dataTables.min.js"></script>

    <script src="bower_components/datatables-plugins/integration/bootstrap/3/dataTables.bootstrap.min.js"></script>

    <script type="text/javascript" src="bower_components/confirmation/bootstrap-confirmation.js"></script>

    <script src="dist/js/sb-admin-2.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/moment@2.20.1/moment.js"></script>
    <script src="js/bootstrap-datetimepicker.min.js"></script>

	